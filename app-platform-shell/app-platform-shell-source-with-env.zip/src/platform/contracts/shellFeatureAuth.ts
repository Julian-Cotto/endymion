export interface ShellFeatureAuthContractV1 {
  version: "v1";
  isAuthenticated: boolean;
  authMode: "none" | "mock" | "entra";
  userId?: string;
  userName?: string;
  email?: string;
  roles?: string[];
  accessToken?: string;
}

export interface ShellFeatureBackendContractV1 {
  baseUrl?: string;
  healthEndpoint?: string;
  enabled?: boolean;
}

export interface ShellFeatureRuntimeContractV1 {
  version: "v1";
  environment?: string;
  featureKey: string;
  route?: string;
  displayName?: string;
  backend?: ShellFeatureBackendContractV1;
  flags?: Record<string, boolean>;
  permissions?: string[];
}

declare global {
  interface Window {
    __FEATURE_SHELL_AUTH__?: ShellFeatureAuthContractV1;
    __FEATURE_SHELL_RUNTIME__?: ShellFeatureRuntimeContractV1;
  }
}