import { describe, expect, it } from "vitest";

import { resolveShellFeatureAuth } from "./resolveShellFeatureAuth";

describe("resolveShellFeatureAuth", () => {
  it("returns v1 mock auth contract", () => {
    const manifest = {
      featureKey: "orders",
      displayName: "Orders",
      version: "1.0.0",
      auth: {
        required: true,
        mode: "mock",
        shellAuthRequired: true,
        tokenForwarding: false,
      },
    };

    const session = {
      isAuthenticated: true,
      userId: "u1",
      userName: "Boris",
      email: "boris@example.com",
      roles: ["developer"],
      accessToken: "token-123",
    };

    const result = resolveShellFeatureAuth(manifest as never, session);

    expect(result).toEqual({
      version: "v1",
      authMode: "mock",
      isAuthenticated: true,
      userId: "u1",
      userName: "Boris",
      email: "boris@example.com",
      roles: ["developer"],
      accessToken: "token-123",
    });
  });

  it("returns undefined when shell auth is not required", () => {
    const manifest = {
      featureKey: "orders",
      displayName: "Orders",
      version: "1.0.0",
      auth: {
        required: false,
        mode: "none",
        shellAuthRequired: false,
        tokenForwarding: false,
      },
    };

    const session = {
      isAuthenticated: false,
      roles: [],
    };

    const result = resolveShellFeatureAuth(manifest as never, session as never);

    expect(result).toBeUndefined();
  });

  it("returns unauthenticated entra contract when session is not authenticated", () => {
    const manifest = {
      featureKey: "orders",
      displayName: "Orders",
      version: "1.0.0",
      auth: {
        required: true,
        mode: "entra",
        shellAuthRequired: true,
        tokenForwarding: true,
      },
    };

    const session = {
      isAuthenticated: false,
      roles: [],
    };

    const result = resolveShellFeatureAuth(manifest as never, session as never);

    expect(result).toEqual({
      version: "v1",
      authMode: "entra",
      isAuthenticated: false,
      roles: [],
    });
  });
});