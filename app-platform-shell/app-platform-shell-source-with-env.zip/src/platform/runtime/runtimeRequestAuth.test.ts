import { afterEach, beforeEach, describe, expect, it } from "vitest";

import {
  clearShellSessionSnapshot,
  setShellSessionSnapshot,
} from "../session/shellSessionStore";
import { buildRuntimeRequestHeaders } from "./runtimeRequestAuth";

describe("buildRuntimeRequestHeaders", () => {
  beforeEach(() => {
    clearShellSessionSnapshot();
  });

  afterEach(() => {
    clearShellSessionSnapshot();
  });

  it("returns Accept header when no token is present", () => {
    expect(buildRuntimeRequestHeaders()).toEqual({
      Accept: "application/json",
    });
  });

  it("includes Authorization header when access token is present", () => {
    setShellSessionSnapshot({
      isAuthenticated: true,
      accessToken: "token-123",
    });

    expect(buildRuntimeRequestHeaders()).toEqual({
      Accept: "application/json",
      Authorization: "Bearer token-123",
    });
  });
});