import { getShellSessionSnapshot } from "../session/shellSessionStore";

export function buildRuntimeRequestHeaders(): HeadersInit {
  const headers: Record<string, string> = {
    Accept: "application/json",
  };

  const session = getShellSessionSnapshot();
  const token = session?.accessToken?.trim();

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  return headers;
}