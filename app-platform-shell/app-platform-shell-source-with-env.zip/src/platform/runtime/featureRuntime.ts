import { bootstrapFeature } from "../bootstrap/bootstrapFeature";
import type { ShellUserSession } from "../auth/sessionTypes";

export interface RunFeatureParams {
  manifestUrl: string;
  container: HTMLElement;
  session: ShellUserSession;
}

export async function runFeature(params: RunFeatureParams): Promise<unknown> {
  return bootstrapFeature(params);
}