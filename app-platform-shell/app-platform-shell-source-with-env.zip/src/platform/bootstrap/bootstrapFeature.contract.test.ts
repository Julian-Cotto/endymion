import { beforeEach, describe, expect, it, vi } from "vitest";

import { bootstrapFeature } from "./bootstrapFeature";
import type { FeatureManifest } from "../contracts/featureManifest";

describe("bootstrapFeature v1 mount contract", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    delete globalThis.__dynamicImportForTest__;
  });

  it("mounts feature with manifest, session, and runtime", async () => {
    const mount = vi.fn(async () => undefined);

    globalThis.__dynamicImportForTest__ = vi.fn(async () => ({
      mount,
    }));

    const manifest = {
      featureKey: "orders",
      displayName: "Orders",
      basePath: "/orders",
      version: "1.0.0",
      environment: "local",
      frontend: {
        enabled: true,
        entryUrl: "http://localhost:3200/src/bootstrap-entry.tsx",
        mountFunction: "mount",
      },
      backend: {
        enabled: true,
        baseUrl: "http://localhost:8100/api/orders",
        healthEndpoint: "/health",
      },
      auth: {
        required: true,
        mode: "mock",
        shellAuthRequired: true,
        tokenForwarding: false,
      },
    };

    const session = {
      isAuthenticated: true,
      userId: "u1",
      userName: "Boris",
      email: "boris@example.com",
      roles: ["developer"],
      accessToken: "token-123",
    };

    const runtime = {
      version: "v1" as const,
      environment: "local",
      featureKey: "orders",
      route: "/orders",
      displayName: "Orders",
      backend: {
        baseUrl: "http://localhost:8100/api/orders",
        enabled: true,
        healthEndpoint: "/health",
      },
      flags: {},
      permissions: ["orders.view"],
    };

    const container = document.createElement("div");

    await bootstrapFeature({
      manifest: manifest as FeatureManifest,
      container,
      session,
      runtime,
    });

    expect(mount).toHaveBeenCalledTimes(1);
    expect(mount).toHaveBeenCalledWith(
      container,
      expect.objectContaining({
        manifest: expect.objectContaining({ featureKey: "orders" }),
        session,
        runtime,
      }),
    );
  });
});