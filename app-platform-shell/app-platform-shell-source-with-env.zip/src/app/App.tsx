import { useEffect, useMemo, useState } from "react";
import {
  InteractionRequiredAuthError,
  InteractionStatus,
  type AccountInfo,
} from "@azure/msal-browser";
import { useMsal } from "@azure/msal-react";

import FeatureHost from "./pages/FeatureHost";
import { ShellAuthProvider } from "./providers/ShellAuthProvider";
import type { ShellUserSession } from "../platform/auth/sessionTypes";
import {
  buildSilentTokenRequest,
  entraApiScopes,
  getShellAuthMode,
  loginRequest,
} from "../platform/auth/msalConfig";
import type { BootstrapFeature, BootstrapResponse } from "../platform/contracts/bootstrapResponse";
import { loadRuntimeFeatures } from "../platform/runtime/loadRuntimeFeatures";
import { getBootstrapUrl } from "../platform/runtime/runtimeClientConfig";
import { setShellSessionSnapshot } from "../platform/session/shellSessionStore";

const LAST_FEATURE_ROUTE_KEY = "app-platform-shell:last-feature-route";

function getCurrentFeatureKey(): string | null {
  const path = window.location.pathname.replace(/^\/+/, "").trim();

  if (!path) {
    return null;
  }

  const [firstSegment] = path.split("/");
  return firstSegment || null;
}

function rememberRoute(route: string): void {
  localStorage.setItem(LAST_FEATURE_ROUTE_KEY, route);
}

function getInitials(session: ShellUserSession): string {
  const source = session.userName ?? session.email ?? session.userId ?? "?";

  const parts = source
    .replace(/@.*$/, "")
    .split(/[.\s_-]+/)
    .map((part) => part.trim())
    .filter(Boolean);

  if (parts.length === 0) {
    return "?";
  }

  return parts
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

function sortFeatures(features: BootstrapFeature[]): BootstrapFeature[] {
  return [...features].sort((left, right) => {
    const leftOrder = left.nav.order ?? 9999;
    const rightOrder = right.nav.order ?? 9999;

    if (leftOrder !== rightOrder) {
      return leftOrder - rightOrder;
    }

    return left.nav.label.localeCompare(right.nav.label);
  });
}

function getDefaultFeature(runtime: BootstrapResponse | null): BootstrapFeature | null {
  if (!runtime || runtime.features.length === 0) {
    return null;
  }

  return sortFeatures(runtime.features)[0];
}

function buildMockSession(): ShellUserSession {
  return {
    isAuthenticated: true,
    userId: "dev-user-1",
    userName: "Boris Moshkovich",
    email: "bmoshkovich@hv.ltd",
    roles: ["developer"],
    accessToken: import.meta.env.VITE_MOCK_ACCESS_TOKEN,
  };
}

function buildSessionFromAccount(account: AccountInfo, accessToken: string): ShellUserSession {
  return {
    isAuthenticated: true,
    userId: account.localAccountId || account.homeAccountId,
    userName: account.name ?? account.username,
    email: account.username,
    roles: [],
    accessToken,
  };
}

function ShellFrame({
  session,
  onLogout,
  tokenStatus,
}: {
  session: ShellUserSession;
  onLogout?: () => void;
  tokenStatus?: string;
}) {
  const bootstrapUrl = getBootstrapUrl();
  const initials = getInitials(session);

  const [runtime, setRuntime] = useState<BootstrapResponse | null>(null);
  const [runtimeError, setRuntimeError] = useState<string | null>(null);
  const [selectedFeatureKey, setSelectedFeatureKey] = useState<string | null>(() =>
    getCurrentFeatureKey(),
  );

  const sessionKey = useMemo(
    () =>
      [
        session.isAuthenticated ? "authenticated" : "anonymous",
        session.userId ?? "",
        session.email ?? "",
        session.accessToken ?? "",
      ].join("|"),
    [session.isAuthenticated, session.userId, session.email, session.accessToken],
  );

  useEffect(() => {
    function handlePopState(): void {
      setSelectedFeatureKey(getCurrentFeatureKey());
    }

    window.addEventListener("popstate", handlePopState);

    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const abortController = new AbortController();

    async function loadRuntime(): Promise<void> {
      try {
        setRuntimeError(null);
        setShellSessionSnapshot(session);

        const response = await loadRuntimeFeatures({
          bootstrapUrl,
          signal: abortController.signal,
        });

        if (cancelled) {
          return;
        }

        setRuntime(response);

        const currentFeatureKey = getCurrentFeatureKey();
        const currentFeature =
          currentFeatureKey &&
          response.features.find((feature) => feature.featureKey === currentFeatureKey);

        if (currentFeature) {
          setSelectedFeatureKey(currentFeature.featureKey);
          rememberRoute(currentFeature.route);
          return;
        }

        const rememberedRoute = localStorage.getItem(LAST_FEATURE_ROUTE_KEY);
        const rememberedFeature =
          rememberedRoute &&
          response.features.find((feature) => feature.route === rememberedRoute);

        const defaultFeature = rememberedFeature || getDefaultFeature(response);

        if (defaultFeature) {
          setSelectedFeatureKey(defaultFeature.featureKey);
          rememberRoute(defaultFeature.route);
          window.history.replaceState(null, "", defaultFeature.route);
        }
      } catch (error) {
        if (cancelled || (error instanceof DOMException && error.name === "AbortError")) {
          return;
        }

        setRuntimeError(error instanceof Error ? error.message : "Failed to load runtime.");
      }
    }

    void loadRuntime();

    return () => {
      cancelled = true;
      abortController.abort();
      setShellSessionSnapshot(null);
    };
  }, [bootstrapUrl, sessionKey]);

  const sortedFeatures = runtime ? sortFeatures(runtime.features) : [];
  const selectedFeature =
    selectedFeatureKey && runtime
      ? runtime.features.find((feature) => feature.featureKey === selectedFeatureKey)
      : null;

  function navigateToFeature(feature: BootstrapFeature): void {
    rememberRoute(feature.route);
    window.history.pushState(null, "", feature.route);
    setSelectedFeatureKey(feature.featureKey);
  }

  return (
    <ShellAuthProvider session={session}>
      <div style={{ padding: 16 }}>
        <h1>App Platform Shell</h1>

        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: "50%",
              border: "1px solid #999",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 700,
            }}
            title={session.email ?? session.userName ?? session.userId}
          >
            {initials}
          </div>

          <div>
            <div>
              <strong>User:</strong> {session.userName ?? session.email ?? session.userId}
            </div>
            {tokenStatus ? <div style={{ fontSize: 12, color: "#555" }}>{tokenStatus}</div> : null}
            {runtime ? (
              <div style={{ fontSize: 12, color: "#555" }}>
                Runtime: {runtime.environment} / {runtime.features.length} feature(s)
              </div>
            ) : null}
          </div>

          {onLogout ? (
            <button type="button" onClick={onLogout} style={{ marginLeft: "auto" }}>
              Sign out
            </button>
          ) : null}
        </div>

        {runtimeError ? (
          <div style={{ border: "1px solid #c00", padding: 12, marginBottom: 12 }}>
            <strong>Runtime load failed</strong>
            <pre style={{ whiteSpace: "pre-wrap" }}>{runtimeError}</pre>
          </div>
        ) : null}

        {!runtime && !runtimeError ? <p>Loading runtime features...</p> : null}

        {runtime && sortedFeatures.length === 0 ? (
          <div style={{ border: "1px solid #cc0", padding: 12, marginBottom: 12 }}>
            No features are available for this user/environment.
          </div>
        ) : null}

        {sortedFeatures.length > 0 ? (
          <>
            <div style={{ marginBottom: 12 }}>
              <strong>Current feature:</strong>{" "}
              {selectedFeature?.displayName ?? selectedFeatureKey ?? "none"}
            </div>

            <div style={{ marginBottom: 12 }}>
              {sortedFeatures.map((feature) => (
                <button
                  key={feature.featureKey}
                  type="button"
                  onClick={() => navigateToFeature(feature)}
                  style={{
                    marginRight: 8,
                    fontWeight: feature.featureKey === selectedFeatureKey ? 700 : 400,
                  }}
                >
                  {feature.nav.label}
                </button>
              ))}
            </div>
          </>
        ) : null}

        <div style={{ border: "1px solid #ccc", minHeight: 300, padding: 12 }}>
          {selectedFeature ? (
            <FeatureHost bootstrapUrl={bootstrapUrl} featureKey={selectedFeature.featureKey} />
          ) : (
            <p>No feature selected.</p>
          )}
        </div>
      </div>
    </ShellAuthProvider>
  );
}

function MockShellApp() {
  const session = useMemo(() => buildMockSession(), []);

  return <ShellFrame session={session} tokenStatus="Mock token active" />;
}

function EntraShellApp() {
  const { instance, accounts, inProgress } = useMsal();
  const [session, setSession] = useState<ShellUserSession | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tokenAcquiredAt, setTokenAcquiredAt] = useState<Date | null>(null);

  const activeAccount = instance.getActiveAccount();
  const account = activeAccount ?? accounts[0] ?? null;

  useEffect(() => {
    if (inProgress !== InteractionStatus.None) {
      return;
    }

    if (!account) {
      void instance.loginRedirect(loginRequest);
    }
  }, [account, inProgress, instance]);

  useEffect(() => {
    if (inProgress !== InteractionStatus.None || !account) {
      return;
    }

    instance.setActiveAccount(account);

    let cancelled = false;

    async function acquireToken(): Promise<void> {
      try {
        if (entraApiScopes.length === 0) {
          throw new Error("VITE_ENTRA_SCOPES is empty.");
        }

        const result = await instance.acquireTokenSilent(buildSilentTokenRequest(account));

        if (!cancelled) {
          setSession(buildSessionFromAccount(account, result.accessToken));
          setTokenAcquiredAt(new Date());
          setError(null);
        }
      } catch (err) {
        if (err instanceof InteractionRequiredAuthError) {
          await instance.acquireTokenRedirect(buildSilentTokenRequest(account));
          return;
        }

        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Token error");
        }
      }
    }

    void acquireToken();

    return () => {
      cancelled = true;
    };
  }, [account, inProgress, instance]);

  function logout(): void {
    const confirmed = window.confirm("Sign out of the App Platform Shell?");
    if (!confirmed) {
      return;
    }

    localStorage.removeItem(LAST_FEATURE_ROUTE_KEY);
    void instance.logoutRedirect();
  }

  if (error) {
    return (
      <div style={{ padding: 16 }}>
        <h1>App Platform Shell</h1>
        <h2>Authentication failed</h2>
        <pre>{error}</pre>
      </div>
    );
  }

  if (!session) {
    return (
      <div style={{ padding: 16 }}>
        <h1>App Platform Shell</h1>
        <p>Signing in...</p>
      </div>
    );
  }

  const tokenStatus = tokenAcquiredAt
    ? `Token refreshed at ${tokenAcquiredAt.toLocaleTimeString()}`
    : "Token pending";

  return <ShellFrame session={session} onLogout={logout} tokenStatus={tokenStatus} />;
}

export default function App() {
  if (getShellAuthMode() === "entra") {
    return <EntraShellApp />;
  }

  return <MockShellApp />;
}