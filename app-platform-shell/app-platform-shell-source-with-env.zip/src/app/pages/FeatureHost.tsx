import { useEffect, useMemo, useRef, useState } from "react";

import { useShellSession } from "../hooks/useShellSession";
import { bootstrapFeature } from "../../platform/bootstrap/bootstrapFeature";
import type { BootstrapFeature } from "../../platform/contracts/bootstrapResponse";
import type { FeatureManifest, FeatureManifestAuth } from "../../platform/contracts/featureManifest";
import { loadRuntimeFeatures } from "../../platform/runtime/loadRuntimeFeatures";
import { setShellSessionSnapshot } from "../../platform/session/shellSessionStore";

interface FeatureHostProps {
  bootstrapUrl: string;
  featureKey: string;
}

function normalizeManifestAuth(auth: BootstrapFeature["auth"] | undefined): FeatureManifestAuth {
  return {
    required: auth?.required ?? false,
    mode: auth?.mode ?? "none",
    shellAuthRequired: auth?.shellAuthRequired ?? false,
    tokenForwarding: auth?.tokenForwarding ?? false,
    tokenStrategy: auth?.tokenStrategy ?? "none",
    allowedDevModes: auth?.allowedDevModes ?? ["none", "mock"],
    roles: auth?.roles ?? [],
  };
}

function asCleanup(value: unknown): (() => void) | undefined {
  if (typeof value !== "function") {
    return undefined;
  }

  return () => {
    value();
  };
}

function runCleanup(cleanup: (() => void) | undefined): void {
  if (!cleanup) {
    return;
  }

  try {
    cleanup();
  } catch (error) {
    console.warn("Feature cleanup failed", error);
  }
}

function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === "AbortError";
}

export default function FeatureHost({ bootstrapUrl, featureKey }: FeatureHostProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const activeCleanupRef = useRef<(() => void) | undefined>(undefined);
  const loadIdRef = useRef(0);

  const session = useShellSession();
  const sessionRef = useRef(session);

  const [error, setError] = useState<string | null>(null);

  const sessionKey = useMemo(
    () =>
      [
        session.isAuthenticated ? "authenticated" : "anonymous",
        session.userId ?? "",
        session.email ?? "",
        session.accessToken ?? "",
      ].join("|"),
    [session.isAuthenticated, session.userId, session.email, session.accessToken],
  );

  useEffect(() => {
    sessionRef.current = session;
    setShellSessionSnapshot(session);

    return () => {
      setShellSessionSnapshot(null);
    };
  }, [sessionKey, session]);

  useEffect(() => {
    let cancelled = false;
    const abortController = new AbortController();
    const loadId = loadIdRef.current + 1;
    loadIdRef.current = loadId;

    async function load(): Promise<void> {
      const container = containerRef.current;

      if (!container) {
        return;
      }

      try {
        setError(null);

        runCleanup(activeCleanupRef.current);
        activeCleanupRef.current = undefined;
        container.replaceChildren();

        const activeSession = sessionRef.current;
        setShellSessionSnapshot(activeSession);

        const bootstrap = await loadRuntimeFeatures({
          bootstrapUrl,
          signal: abortController.signal,
        });

        if (cancelled || loadId !== loadIdRef.current) {
          return;
        }

        const feature = bootstrap.features.find(
          (candidate) => candidate.featureKey === featureKey,
        );

        if (!feature) {
          throw new Error(`Feature '${featureKey}' not found in bootstrap response.`);
        }

        const manifest: FeatureManifest = {
          featureKey: feature.featureKey,
          displayName: feature.displayName,
          basePath: feature.route,
          version: feature.version,
          environment: bootstrap.environment,
          frontend: {
            enabled: feature.frontend.enabled ?? true,
            entryUrl: feature.frontend.entryUrl,
            mountFunction: feature.frontend.mountFunction || "mount",
          },
          backend: {
            enabled: feature.backend.enabled ?? true,
            baseUrl: feature.backend.apiBaseUrl,
            healthEndpoint: feature.backend.healthEndpoint,
          },
          auth: normalizeManifestAuth(feature.auth),
        };

        const cleanup = await bootstrapFeature({
          manifest,
          container,
          session: activeSession,
          runtime: {
            version: "v1",
            environment: bootstrap.environment,
            featureKey: feature.featureKey,
            route: feature.route,
            displayName: feature.displayName,
            backend: {
              baseUrl: feature.backend.apiBaseUrl,
              enabled: feature.backend.enabled ?? true,
              healthEndpoint: feature.backend.healthEndpoint,
            },
            flags: bootstrap.flags,
            permissions: bootstrap.permissions,
          },
        });

        const cleanupFn = asCleanup(cleanup);

        if (cancelled || loadId !== loadIdRef.current) {
          runCleanup(cleanupFn);
          container.replaceChildren();
          return;
        }

        activeCleanupRef.current = cleanupFn;
      } catch (err) {
        if (isAbortError(err)) {
          return;
        }

        if (!cancelled && loadId === loadIdRef.current) {
          const message = err instanceof Error ? err.message : "Failed to load feature.";
          setError(message);
          console.error("Failed to bootstrap feature", err);
        }
      }
    }

    void load();

    return () => {
      cancelled = true;
      abortController.abort();

      runCleanup(activeCleanupRef.current);
      activeCleanupRef.current = undefined;

      if (containerRef.current) {
        containerRef.current.replaceChildren();
      }
    };
  }, [bootstrapUrl, featureKey, sessionKey]);

  if (error) {
    return (
      <div>
        <h2>Feature load failed</h2>
        <p>{error}</p>
      </div>
    );
  }

  return <div ref={containerRef} />;
}