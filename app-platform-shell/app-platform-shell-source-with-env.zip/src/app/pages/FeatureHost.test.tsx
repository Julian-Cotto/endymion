import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";

import FeatureHost from "./FeatureHost";
import { useShellSession } from "../hooks/useShellSession";
import { bootstrapFeature } from "../../platform/bootstrap/bootstrapFeature";
import { loadRuntimeFeatures } from "../../platform/runtime/loadRuntimeFeatures";

vi.mock("../hooks/useShellSession", () => ({
  useShellSession: vi.fn(),
}));

vi.mock("../../platform/bootstrap/bootstrapFeature", () => ({
  bootstrapFeature: vi.fn(),
}));

vi.mock("../../platform/runtime/loadRuntimeFeatures", () => ({
  loadRuntimeFeatures: vi.fn(),
}));

describe("FeatureHost", () => {
  let consoleErrorSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    vi.clearAllMocks();
    consoleErrorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    consoleErrorSpy.mockRestore();
  });

  it("loads runtime response, selects feature, and calls bootstrapFeature with manifest", async () => {
    vi.mocked(loadRuntimeFeatures).mockResolvedValueOnce({
      environment: "dev",
      user: {
        id: "u1",
        displayName: "Boris",
        email: "boris@example.com",
      },
      permissions: ["orders.view"],
      flags: {
        "orders.enabled": true,
      },
      features: [
        {
          featureKey: "orders",
          displayName: "Orders",
          route: "/orders",
          version: "1.0.0",
          nav: {
            label: "Orders",
            icon: "package",
          },
          frontend: {
            enabled: true,
            entryUrl: "http://localhost:3200/src/bootstrap-entry.tsx",
            mountFunction: "mount",
          },
          backend: {
            enabled: true,
            apiBaseUrl: "http://localhost:8100/api/orders",
            healthEndpoint: "/health",
          },
          authorization: {
            requiredPermissions: [],
            requiredFlags: [],
          },
          auth: {
            required: true,
            mode: "mock",
            shellAuthRequired: true,
            tokenForwarding: false,
          },
        },
      ],
      metadata: {
        source: "bootstrap",
      },
    } as never);

    vi.mocked(useShellSession).mockReturnValue({
      isAuthenticated: true,
      userId: "u1",
      userName: "Boris",
      email: "boris@example.com",
      roles: ["developer"],
      accessToken: "token-123",
    } as never);

    vi.mocked(bootstrapFeature).mockResolvedValue(undefined);

    render(
      <FeatureHost
        bootstrapUrl="http://localhost:8001/api/shell/bootstrap"
        featureKey="orders"
      />,
    );

    await waitFor(() => {
      expect(loadRuntimeFeatures).toHaveBeenCalledTimes(1);
      expect(bootstrapFeature).toHaveBeenCalledTimes(1);
    });

    expect(bootstrapFeature).toHaveBeenCalledWith(
      expect.objectContaining({
        manifest: expect.objectContaining({
          featureKey: "orders",
          displayName: "Orders",
          basePath: "/orders",
          version: "1.0.0",
          environment: "dev",
          frontend: expect.objectContaining({
            enabled: true,
            entryUrl: "http://localhost:3200/src/bootstrap-entry.tsx",
            mountFunction: "mount",
          }),
          backend: expect.objectContaining({
            enabled: true,
            baseUrl: "http://localhost:8100/api/orders",
            healthEndpoint: "/health",
          }),
        }),
        session: expect.objectContaining({
          isAuthenticated: true,
          userId: "u1",
        }),
        runtime: expect.objectContaining({
          version: "v1",
          featureKey: "orders",
          route: "/orders",
          displayName: "Orders",
          backend: expect.objectContaining({
            baseUrl: "http://localhost:8100/api/orders",
            enabled: true,
            healthEndpoint: "/health",
          }),
          flags: {
            "orders.enabled": true,
          },
          permissions: ["orders.view"],
        }),
      }),
    );
  });

  it("renders an error message when runtime loading fails", async () => {
    vi.mocked(loadRuntimeFeatures).mockRejectedValueOnce(new Error("Boom"));

    vi.mocked(useShellSession).mockReturnValue({
      isAuthenticated: true,
      userId: "u1",
      userName: "Boris",
      email: "boris@example.com",
      roles: ["developer"],
      accessToken: "token-123",
    } as never);

    render(
      <FeatureHost
        bootstrapUrl="http://localhost:8001/api/shell/bootstrap"
        featureKey="orders"
      />,
    );

    expect(await screen.findByText("Feature load failed")).toBeInTheDocument();
    expect(await screen.findByText("Boom")).toBeInTheDocument();
  });

  it("renders an error when the requested feature is missing", async () => {
    vi.mocked(loadRuntimeFeatures).mockResolvedValueOnce({
      environment: "dev",
      user: {
        id: "u1",
        displayName: "Boris",
        email: "boris@example.com",
      },
      permissions: [],
      flags: {},
      features: [],
      metadata: {
        source: "bootstrap",
      },
    } as never);

    vi.mocked(useShellSession).mockReturnValue({
      isAuthenticated: true,
      userId: "u1",
      userName: "Boris",
      email: "boris@example.com",
      roles: ["developer"],
      accessToken: "token-123",
    } as never);

    render(
      <FeatureHost
        bootstrapUrl="http://localhost:8001/api/shell/bootstrap"
        featureKey="orders"
      />,
    );

    expect(await screen.findByText("Feature load failed")).toBeInTheDocument();
    expect(
      await screen.findByText("Feature 'orders' not found in bootstrap response."),
    ).toBeInTheDocument();
  });
});