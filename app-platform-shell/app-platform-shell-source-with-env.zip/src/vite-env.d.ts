/// <reference types="vite/client" />

declare global {
  // eslint-disable-next-line no-var
  var __dynamicImportForTest__:
    | ((url: string) => Promise<Record<string, unknown>>)
    | undefined;
}

export {};
